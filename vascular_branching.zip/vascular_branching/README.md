# vascular_branching

> Fractal vessels: the geometry of blood, rivers, and trees.

## What This Is

Vascular systems — blood vessels, river deltas, tree branches — share a common geometry: **space-filling branching fractals** that optimize transport. This repo generates and visualizes these patterns.

## Key Models

### 1. Diffusion-Limited Aggregation (DLA)
Particles random-walk and stick. Creates fractal trees.

### 2. Constructive Solid Geometry (CSG)
Recursive splitting: each branch splits into 2+ smaller branches.

### 3. Murray's Law
Optimal branching: r_parent³ = r_child1³ + r_child2³ (conserves flow with minimal energy).

### 4. Space Colonization
Grow toward attractor points (leaves, tissue regions).

## Parameters

- `branching_angle` — angle between sibling branches
- `length_ratio` — child length / parent length
- `diameter_ratio` — child diameter / parent diameter
- ` Murray_optimized` — enforce r³ law
- `attraction_points` — space colonization targets
- `vein_vs_artery` — oxygenated (red) vs deoxygenated (blue)

## Visual Styles

- **Anatomical** — realistic vascular networks
- **Botanical** — tree branches, leaf venation
- **River delta** — meandering, sediment deposition
- **Circuit board** — artificial, angular
- **Neural** — neurons, synaptic trees

## Related

- `dla_cluster` — same physics, different framing
- `mycelial_network` — fungal analog

---

*Every vascular system is a tree. Every tree is a vascular system. The geometry doesn't care what flows through it.*
